import streamlit as st
import json
from datetime import datetime
import io

# Title and introduction
st.set_page_config(page_title="Guides AI", page_icon="🌍")
st.title("🌍 Guides AI - Your Personal Trip Planner")
st.markdown("Plan a personalized trip using AI based on your preferences and budget.")

# Initialize session state for itinerary
if 'generated_itinerary' not in st.session_state:
    st.session_state.generated_itinerary = None
if 'trip_data' not in st.session_state:
    st.session_state.trip_data = None

# Sidebar input
with st.sidebar:
    st.header("📝 Trip Preferences")
    location = st.text_input("Destination", "Goa")
    days = st.slider("Trip Duration (Days)", 1, 10, 3)
    budget = st.number_input("Total Budget (₹)", min_value=1000, step=500, value=10000)
    preferences = st.multiselect("Travel Interests", 
                                 ["Culture", "Adventure", "Food", "Nightlife", "Relaxation"], 
                                 default=["Culture"])

# Sample itinerary generator (mock logic)
def generate_itinerary(location, days, budget, preferences):
    pref_text = ", ".join(preferences)
    
    # Create detailed itinerary based on days
    day_activities = []
    for day in range(1, days + 1):
        if day == 1:
            activity = "Explore main attractions and local cuisine"
        elif day == 2:
            activity = "Adventure activities or cultural sightseeing"
        elif day == 3:
            activity = "Relaxation and shopping for souvenirs"
        else:
            activity = f"Day {day} exploration and local experiences"
        day_activities.append(f"🎯 *Day {day}*: {activity}")
    
    itinerary_text = f"""
✅ *{days}-Day Trip to {location} (Budget: ₹{budget})*

{chr(10).join(day_activities)}

🏨 *Stay*: Budget hotel near city center  
🍛 *Food*: Try famous dishes and street food  
🚖 *Transport*: Use local taxis or rent a scooter  
💸 *Estimated Total Cost*: ₹{budget - 500}  

💡 *Interests Covered*: {pref_text}
"""
    
    # Store trip data for saving
    trip_data = {
        "destination": location,
        "duration_days": days,
        "budget": budget,
        "preferences": preferences,
        "itinerary": itinerary_text,
        "generated_at": datetime.now().isoformat(),
        "estimated_cost": budget - 500
    }
    
    return itinerary_text, trip_data

# Generate button
if st.button("Generate Itinerary"):
    if not location:
        st.warning("Please enter a destination.")
    else:
        with st.spinner("Creating your personalized itinerary..."):
            output, trip_data = generate_itinerary(location, days, budget, preferences)
            st.session_state.generated_itinerary = output
            st.session_state.trip_data = trip_data
            st.subheader("🗺️ Your AI-Powered Itinerary")
            st.markdown(output)
            st.success("Your itinerary is ready! Use the save options below.")

# Display saved itinerary if it exists
if st.session_state.generated_itinerary:
    st.subheader("🗺️ Your AI-Powered Itinerary")
    st.markdown(st.session_state.generated_itinerary)
    
    # "Save This Life" functionality - Save and Export Options
    st.markdown("---")
    st.subheader("💾 Save This Life - Export Your Trip")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        # Save as JSON
        if st.button("📄 Save as JSON"):
            json_data = json.dumps(st.session_state.trip_data, indent=2)
            st.download_button(
                label="⬇️ Download JSON",
                data=json_data,
                file_name=f"trip_plan_{st.session_state.trip_data['destination'].lower().replace(' ', '_')}_{datetime.now().strftime('%Y%m%d')}.json",
                mime="application/json"
            )
            st.success("JSON export ready!")
    
    with col2:
        # Save as Text
        if st.button("📝 Save as Text"):
            text_data = f"""GUIDES AI - TRIP PLAN
{'-' * 40}

{st.session_state.generated_itinerary}

Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Saved via Guides AI Trip Planner
"""
            st.download_button(
                label="⬇️ Download Text",
                data=text_data,
                file_name=f"trip_plan_{st.session_state.trip_data['destination'].lower().replace(' ', '_')}_{datetime.now().strftime('%Y%m%d')}.txt",
                mime="text/plain"
            )
            st.success("Text export ready!")
    
    with col3:
        # Copy to Clipboard option
        if st.button("📋 Copy to Clipboard"):
            st.code(st.session_state.generated_itinerary, language=None)
            st.info("Select and copy the text above!")

    # Emergency "Save This Life" button - saves all data
    st.markdown("---")
    if st.button("🆘 SAVE THIS LIFE - Emergency Backup", type="primary", use_container_width=True):
        emergency_data = {
            "emergency_backup": True,
            "timestamp": datetime.now().isoformat(),
            "trip_details": st.session_state.trip_data,
            "note": "Emergency backup of your precious trip plan!"
        }
        emergency_json = json.dumps(emergency_data, indent=2)
        st.download_button(
            label="⚡ DOWNLOAD EMERGENCY BACKUP",
            data=emergency_json,
            file_name=f"EMERGENCY_TRIP_BACKUP_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            mime="application/json",
            type="primary",
            use_container_width=True
        )
        st.success("🎉 Life saved! Your trip plan is safely backed up!")

# Footer
st.markdown("---")
st.caption("🚀 Built for GenAI Exchange Hackathon | By Team Guides AI | 💾 Save This Life Feature")
