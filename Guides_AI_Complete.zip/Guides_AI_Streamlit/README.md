# 🌍 Guides AI (Streamlit Prototype)

This is a working prototype of *Guides AI*, an AI-powered personalized trip planner built for the GenAI Exchange Hackathon by Google Cloud.

## ✅ Features

- **Input**: Budget, destination, preferences, trip duration
- **Output**: Smart AI-generated itinerary with detailed day-by-day plans
- **💾 Save This Life**: Multiple export options to save your precious trip plans
  - JSON export with full trip data
  - Text file export for easy sharing
  - Copy to clipboard functionality
  - Emergency backup feature
- **Simple UI** with Streamlit
- **Offline mode** (no external API required for demo)

## 🆘 Save This Life Feature

The "Save This Life" functionality ensures you never lose your perfect trip plan:

1. **📄 JSON Export**: Complete trip data with metadata
2. **📝 Text Export**: Clean, readable format for sharing
3. **📋 Copy to Clipboard**: Quick copy for messaging apps
4. **🆘 Emergency Backup**: One-click full backup of all trip details

## 🚀 How to Run

```bash
pip install streamlit pandas
streamlit run app.py
```

## 📱 Usage

1. Enter your destination in the sidebar
2. Set your budget and trip duration
3. Select your travel interests
4. Click "Generate Itinerary"
5. Use "Save This Life" options to export your plan

## 🔧 Installation

1. Extract the zip file
2. Navigate to Guides_AI_Streamlit/
3. Install dependencies: `pip install -r requirements.txt`
4. Run the app: `streamlit run app.py`

## 💡 Why "Save This Life"?

Your perfect trip plan is precious - don't let it disappear! The "Save This Life" feature ensures your carefully crafted itinerary is always safe and shareable.

## 🚀 How to Run

```bash
pip install streamlit
streamlit run app.py
```

## 📱 Features
- AI-powered itinerary generation
- Save and export trip plans
- Budget-based recommendations
- Interactive UI with preferences

## 🔧 Installation
1. Extract the zip file
2. Navigate to Guides_AI_Streamlit/
3. Install dependencies: `pip install streamlit`
4. Run the app: `streamlit run app.py`
